const { MessageFlags } = require('discord.js');
const config = require('../config');
const ids = require('../utils/ids');
const { isGestaoOrAbove } = require('../utils/permissions');
const { getAuthorId } = require('../utils/embeds');

const EPHEMERAL = MessageFlags.Ephemeral;

/** Botão "Ver autor" na confissão pública. Só Gestão+ recebe a resposta. */
async function viewAuthor(interaction) {
  if (!(await isGestaoOrAbove(interaction.member))) {
    return interaction.reply({
      content: '🚫 Apenas a **Gestão+** pode ver quem enviou.',
      flags: EPHEMERAL,
    });
  }

  await interaction.deferReply({ flags: EPHEMERAL });

  const reviewMessageId = interaction.customId.slice(ids.VIEW_AUTHOR_PREFIX.length);
  const reviewChannel = await interaction.client.channels
    .fetch(config.reviewChannelId)
    .catch(() => null);
  const reviewMessage = await reviewChannel?.messages.fetch(reviewMessageId).catch(() => null);
  const authorId = getAuthorId(reviewMessage?.embeds[0]);

  if (!authorId) {
    return interaction.editReply(
      '⚠️ Não encontrei o registro desta confissão no canal da gestão (a mensagem pode ter sido apagada).',
    );
  }

  await interaction.editReply({
    content: `🔎 Autor: <@${authorId}> (\`${authorId}\`)`,
    allowedMentions: { parse: [] },
  });

  // Registro de auditoria: fica visível para toda a gestão.
  await reviewMessage
    .reply({
      content: `👁️ ${interaction.user} consultou o autor desta confissão.`,
      allowedMentions: { parse: [] },
    })
    .catch(() => {});
}

module.exports = { viewAuthor };
