const {
  ActionRowBuilder,
  MessageFlags,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require('discord.js');
const config = require('../config');
const ids = require('../utils/ids');
const { isGestaoOrAbove } = require('../utils/permissions');
const {
  getAuthorId,
  publicEmbed,
  publicRow,
  resolveReviewEmbed,
} = require('../utils/embeds');

const EPHEMERAL = MessageFlags.Ephemeral;

// Evita que dois membros da gestão decidam a mesma confissão ao mesmo tempo.
const processing = new Set();

const NO_PERMISSION = {
  content: '🚫 Apenas a **Gestão+** pode analisar confissões.',
  flags: EPHEMERAL,
};

async function notifyAuthor(interaction, authorId, status, reason) {
  if (!config.notifyAuthor || !authorId) return;
  try {
    const user = await interaction.client.users.fetch(authorId);
    const server = interaction.guild.name;
    const text =
      status === 'approved'
        ? `✅ Sua confissão em **${server}** foi aprovada e publicada.`
        : `❌ Sua confissão em **${server}** foi recusada pela gestão.${
            reason ? `\n**Motivo:** ${reason}` : ''
          }`;
    await user.send(text);
  } catch {
    // DMs fechadas — tudo bem, segue o jogo.
  }
}

/** Lógica única para aprovar/recusar. Espera que a interação já tenha dado deferReply. */
async function finalizeReview(interaction, message, status, reason = null) {
  if (processing.has(message.id)) {
    return interaction.editReply('⏳ Outra pessoa da gestão já está analisando esta confissão.');
  }
  if (!message.components.length) {
    return interaction.editReply('ℹ️ Esta confissão já foi analisada.');
  }

  processing.add(message.id);
  try {
    const oldEmbed = message.embeds[0];
    const authorId = getAuthorId(oldEmbed);

    if (status === 'approved') {
      const channel = await interaction.client.channels.fetch(config.confessionsChannelId);
      await channel.send({
        embeds: [publicEmbed(oldEmbed.description)],
        components: [publicRow(message.id)],
        allowedMentions: { parse: [] },
      });
    }

    await message.edit({
      embeds: [
        resolveReviewEmbed(oldEmbed, {
          status,
          reviewerId: interaction.user.id,
          reason,
        }),
      ],
      components: [],
      allowedMentions: { parse: [] },
    });

    await notifyAuthor(interaction, authorId, status, reason);

    await interaction.editReply(
      status === 'approved'
        ? '✅ Confissão aprovada e publicada.'
        : '❌ Confissão recusada.',
    );
  } catch (err) {
    console.error('Erro ao finalizar revisão:', err);
    await interaction
      .editReply('⚠️ Algo deu errado. Confira as permissões do bot nos canais de confissões e de revisão.')
      .catch(() => {});
  } finally {
    processing.delete(message.id);
  }
}

/** Botão ✅ Aprovar */
async function onApprove(interaction) {
  if (!(await isGestaoOrAbove(interaction.member))) {
    return interaction.reply(NO_PERMISSION);
  }
  await interaction.deferReply({ flags: EPHEMERAL });
  await finalizeReview(interaction, interaction.message, 'approved');
}

/** Botão ❌ Recusar → pede um motivo (opcional) num formulário. */
async function onRejectButton(interaction) {
  if (!(await isGestaoOrAbove(interaction.member))) {
    return interaction.reply(NO_PERMISSION);
  }

  const input = new TextInputBuilder()
    .setCustomId(ids.INPUT_REASON)
    .setLabel('Motivo (opcional)')
    .setStyle(TextInputStyle.Paragraph)
    .setPlaceholder('Será enviado ao autor por DM, se estiver ativado.')
    .setMaxLength(500)
    .setRequired(false);

  const modal = new ModalBuilder()
    .setCustomId(`${ids.REJECT_MODAL_PREFIX}${interaction.message.id}`)
    .setTitle('Recusar confissão')
    .addComponents(new ActionRowBuilder().addComponents(input));

  await interaction.showModal(modal);
}

/** Formulário de recusa enviado. */
async function onRejectModal(interaction) {
  if (!(await isGestaoOrAbove(interaction.member))) {
    return interaction.reply(NO_PERMISSION);
  }
  await interaction.deferReply({ flags: EPHEMERAL });

  const messageId = interaction.customId.slice(ids.REJECT_MODAL_PREFIX.length);
  const message = await interaction.channel.messages.fetch(messageId).catch(() => null);
  if (!message) {
    return interaction.editReply('⚠️ Não encontrei a mensagem desta confissão.');
  }

  const reason = interaction.fields.getTextInputValue(ids.INPUT_REASON).trim() || null;
  await finalizeReview(interaction, message, 'rejected', reason);
}

module.exports = { onApprove, onRejectButton, onRejectModal };
