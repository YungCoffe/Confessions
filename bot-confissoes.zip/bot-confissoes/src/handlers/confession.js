const {
  ActionRowBuilder,
  MessageFlags,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require('discord.js');
const config = require('../config');
const ids = require('../utils/ids');
const cooldown = require('../utils/cooldown');
const { reviewEmbed, reviewRow } = require('../utils/embeds');

const EPHEMERAL = MessageFlags.Ephemeral;

/** Botão do painel → abre o formulário. */
async function openConfessionModal(interaction) {
  const wait = cooldown.secondsLeft(interaction.user.id);
  if (wait > 0) {
    return interaction.reply({
      content: `⏳ Aguarde **${wait}s** para enviar outra confissão.`,
      flags: EPHEMERAL,
    });
  }

  const input = new TextInputBuilder()
    .setCustomId(ids.INPUT_CONTENT)
    .setLabel('Sua confissão')
    .setStyle(TextInputStyle.Paragraph)
    .setPlaceholder('Escreva o que quiser. Nomes, @ e # são permitidos.')
    .setMinLength(5)
    .setMaxLength(config.maxLength)
    .setRequired(true);

  const modal = new ModalBuilder()
    .setCustomId(ids.SUBMIT_MODAL)
    .setTitle('Enviar confissão')
    .addComponents(new ActionRowBuilder().addComponents(input));

  await interaction.showModal(modal);
}

/** Formulário enviado → vai para o canal de revisão da gestão. */
async function submitConfession(interaction) {
  await interaction.deferReply({ flags: EPHEMERAL });

  const wait = cooldown.secondsLeft(interaction.user.id);
  if (wait > 0) {
    return interaction.editReply(`⏳ Aguarde **${wait}s** para enviar outra confissão.`);
  }

  const content = interaction.fields.getTextInputValue(ids.INPUT_CONTENT).trim();
  if (!content) {
    return interaction.editReply('⚠️ A confissão não pode ficar vazia.');
  }

  const reviewChannel = await interaction.client.channels
    .fetch(config.reviewChannelId)
    .catch(() => null);

  if (!reviewChannel?.isTextBased()) {
    console.error('❌ Canal de revisão não encontrado. Confira REVIEW_CHANNEL_ID.');
    return interaction.editReply('⚠️ Não consegui enviar agora. Avise a gestão.');
  }

  await reviewChannel.send({
    embeds: [reviewEmbed({ content, author: interaction.user })],
    components: [reviewRow()],
    allowedMentions: { parse: [] }, // nunca marca ninguém, mesmo com @ no texto
  });

  cooldown.mark(interaction.user.id);
  await interaction.editReply(
    '✅ Sua confissão foi enviada para análise da gestão. Se for aprovada, ela será publicada de forma anônima.',
  );
}

module.exports = { openConfessionModal, submitConfession };
