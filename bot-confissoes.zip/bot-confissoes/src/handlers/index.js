const { MessageFlags } = require('discord.js');
const ids = require('../utils/ids');
const commands = require('../commands');
const { openConfessionModal, submitConfession } = require('./confession');
const { onApprove, onRejectButton, onRejectModal } = require('./review');
const { viewAuthor } = require('./viewAuthor');

const commandMap = new Map(commands.map((c) => [c.data.name, c]));

async function route(interaction) {
  if (interaction.isChatInputCommand()) {
    return commandMap.get(interaction.commandName)?.execute(interaction);
  }

  if (interaction.isButton()) {
    const id = interaction.customId;
    if (id === ids.OPEN_PANEL) return openConfessionModal(interaction);
    if (id === ids.APPROVE) return onApprove(interaction);
    if (id === ids.REJECT) return onRejectButton(interaction);
    if (id.startsWith(ids.VIEW_AUTHOR_PREFIX)) return viewAuthor(interaction);
    return;
  }

  if (interaction.isModalSubmit()) {
    const id = interaction.customId;
    if (id === ids.SUBMIT_MODAL) return submitConfession(interaction);
    if (id.startsWith(ids.REJECT_MODAL_PREFIX)) return onRejectModal(interaction);
  }
}

async function handleInteraction(interaction) {
  try {
    await route(interaction);
  } catch (err) {
    console.error('Erro na interação:', err);
    const payload = { content: '⚠️ Ocorreu um erro inesperado.', flags: MessageFlags.Ephemeral };
    if (interaction.deferred || interaction.replied) {
      await interaction.followUp(payload).catch(() => {});
    } else {
      await interaction.reply(payload).catch(() => {});
    }
  }
}

module.exports = { handleInteraction };
