const { REST, Routes } = require('discord.js');
const config = require('./config');
const commands = require('./commands');

(async () => {
  const rest = new REST().setToken(config.token);
  await rest.put(Routes.applicationGuildCommands(config.clientId, config.guildId), {
    body: commands.map((c) => c.data.toJSON()),
  });
  console.log(`✅ ${commands.length} comando(s) registrado(s) no servidor.`);
})().catch((err) => {
  console.error(err);
  process.exit(1);
});
