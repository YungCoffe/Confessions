const {
  InteractionContextType,
  MessageFlags,
  PermissionFlagsBits,
  SlashCommandBuilder,
} = require('discord.js');
const { isGestaoOrAbove } = require('../utils/permissions');
const { panelEmbed, panelRow } = require('../utils/embeds');

const data = new SlashCommandBuilder()
  .setName('painel-confissoes')
  .setDescription('Envia o painel de confissões neste canal')
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
  .setContexts(InteractionContextType.Guild);

async function execute(interaction) {
  if (!(await isGestaoOrAbove(interaction.member))) {
    return interaction.reply({
      content: '🚫 Apenas a **Gestão+** pode usar este comando.',
      flags: MessageFlags.Ephemeral,
    });
  }

  await interaction.channel.send({ embeds: [panelEmbed()], components: [panelRow()] });
  await interaction.reply({ content: '✅ Painel enviado neste canal.', flags: MessageFlags.Ephemeral });
}

module.exports = { data, execute };
