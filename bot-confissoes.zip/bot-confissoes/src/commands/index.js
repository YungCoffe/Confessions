module.exports = [require('./painel')];
