const http = require('node:http');
const { Client, Events, GatewayIntentBits } = require('discord.js');
const config = require('./config');
const { handleInteraction } = require('./handlers');

// Só o intent "Guilds" — não precisa de nenhum intent privilegiado.
const client = new Client({ intents: [GatewayIntentBits.Guilds] });

client.once(Events.ClientReady, (c) => console.log(`✅ Online como ${c.user.tag}`));
client.on(Events.InteractionCreate, handleInteraction);
client.on(Events.Error, (err) => console.error('Erro do client:', err));
process.on('unhandledRejection', (err) => console.error('Promise rejeitada:', err));

client.login(config.token);

// Alguns hosts (ex.: Render como Web Service) exigem uma porta aberta.
if (process.env.PORT) {
  http
    .createServer((_req, res) => res.end('ok'))
    .listen(process.env.PORT, () => console.log(`🌐 Health check na porta ${process.env.PORT}`));
}
