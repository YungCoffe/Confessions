const { PermissionFlagsBits } = require('discord.js');
const config = require('../config');

/**
 * "Gestão+" = quem tem o cargo Gestão OU qualquer cargo acima dele
 * na hierarquia. Dono do servidor e Administradores também passam.
 */
async function isGestaoOrAbove(member) {
  if (!member?.guild) return false;
  if (member.guild.ownerId === member.id) return true;
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;

  const gestaoRole =
    member.guild.roles.cache.get(config.gestaoRoleId) ??
    (await member.guild.roles.fetch(config.gestaoRoleId).catch(() => null));
  if (!gestaoRole) return false;

  return member.roles.highest.position >= gestaoRole.position;
}

module.exports = { isGestaoOrAbove };
