const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} = require('discord.js');
const config = require('../config');
const ids = require('./ids');

// O ID do autor fica no rodapé do embed do canal PRIVADO da gestão.
// É assim que o bot sabe quem enviou sem precisar de banco de dados.
const AUTHOR_FOOTER_PREFIX = 'ID do autor: ';

const STATUS = {
  pending: { label: '⏳ Aguardando análise', color: config.colors.pending },
  approved: { label: '✅ Aprovada', color: config.colors.approved },
  rejected: { label: '❌ Recusada', color: config.colors.rejected },
};

/* ------------------------------ Painel ------------------------------ */

function panelEmbed() {
  return new EmbedBuilder()
    .setColor(config.colors.brand)
    .setTitle('🤫 Confessionário')
    .setDescription(
      [
        'Quer desabafar, contar algo ou deixar um recado? Clique no botão abaixo e escreva o que quiser — nomes, @ e # são permitidos.',
        '',
        '**Como funciona**',
        '1️⃣ Você envia sua confissão pelo botão.',
        '2️⃣ A gestão analisa e **aprova** ou **recusa**.',
        `3️⃣ Se aprovada, ela é publicada de forma anônima em <#${config.confessionsChannelId}>.`,
        '',
        '🔒 Os membros não veem quem enviou, mas **a gestão tem acesso ao autor** de todas as confissões.',
      ].join('\n'),
    );
}

function panelRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(ids.OPEN_PANEL)
      .setLabel('Enviar confissão')
      .setEmoji('✍️')
      .setStyle(ButtonStyle.Primary),
  );
}

/* ------------------- Canal de revisão (só Gestão+) ------------------- */

function reviewEmbed({ content, author }) {
  return new EmbedBuilder()
    .setColor(STATUS.pending.color)
    .setTitle('📨 Nova confissão')
    .setDescription(content)
    .addFields(
      { name: 'Autor', value: `<@${author.id}> (\`${author.username}\`)`, inline: true },
      { name: 'Status', value: STATUS.pending.label, inline: true },
    )
    .setFooter({ text: `${AUTHOR_FOOTER_PREFIX}${author.id}` })
    .setTimestamp();
}

function reviewRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(ids.APPROVE)
      .setLabel('Aprovar')
      .setEmoji('✅')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(ids.REJECT)
      .setLabel('Recusar')
      .setEmoji('❌')
      .setStyle(ButtonStyle.Danger),
  );
}

/** Reaproveita o embed original e só atualiza status/quem decidiu/motivo. */
function resolveReviewEmbed(oldEmbed, { status, reviewerId, reason }) {
  const s = STATUS[status];
  const authorField = oldEmbed.fields.find((f) => f.name === 'Autor');

  const fields = [
    authorField,
    { name: 'Status', value: s.label, inline: true },
    {
      name: status === 'approved' ? 'Aprovada por' : 'Recusada por',
      value: `<@${reviewerId}>`,
      inline: true,
    },
  ].filter(Boolean);

  if (reason) fields.push({ name: 'Motivo', value: reason.slice(0, 1024) });

  return EmbedBuilder.from(oldEmbed).setColor(s.color).setFields(fields);
}

function getAuthorId(embed) {
  const match = embed?.footer?.text?.match(/\d{17,20}/);
  return match ? match[0] : null;
}

/* ------------------------- Canal público ------------------------- */

function publicEmbed(content) {
  return new EmbedBuilder()
    .setColor(config.colors.brand)
    .setTitle('💬 Confissão anônima')
    .setDescription(content)
    .setFooter({ text: 'Aprovada pela gestão • autor anônimo' })
    .setTimestamp();
}

function publicRow(reviewMessageId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`${ids.VIEW_AUTHOR_PREFIX}${reviewMessageId}`)
      .setLabel('Ver autor (Gestão+)')
      .setEmoji('🔎')
      .setStyle(ButtonStyle.Secondary),
  );
}

module.exports = {
  panelEmbed,
  panelRow,
  reviewEmbed,
  reviewRow,
  resolveReviewEmbed,
  getAuthorId,
  publicEmbed,
  publicRow,
};
