const config = require('../config');

const lastSubmit = new Map();

function secondsLeft(userId) {
  const last = lastSubmit.get(userId);
  if (!last) return 0;
  const left = last + config.cooldownMs - Date.now();
  return left > 0 ? Math.ceil(left / 1000) : 0;
}

function mark(userId) {
  lastSubmit.set(userId, Date.now());
}

module.exports = { secondsLeft, mark };
