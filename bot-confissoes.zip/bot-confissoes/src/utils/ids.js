// Todos os customIds num lugar só, pra não ter string solta pelo código.
module.exports = {
  OPEN_PANEL: 'confession:open',
  SUBMIT_MODAL: 'confession:submit',
  APPROVE: 'review:approve',
  REJECT: 'review:reject',
  REJECT_MODAL_PREFIX: 'review:reject-modal:', // + ID da mensagem de revisão
  VIEW_AUTHOR_PREFIX: 'author:view:', // + ID da mensagem de revisão

  INPUT_CONTENT: 'content',
  INPUT_REASON: 'reason',
};
