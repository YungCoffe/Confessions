require('dotenv').config();

const REQUIRED = [
  'DISCORD_TOKEN',
  'CLIENT_ID',
  'GUILD_ID',
  'CONFESSIONS_CHANNEL_ID',
  'REVIEW_CHANNEL_ID',
  'GESTAO_ROLE_ID',
];

const missing = REQUIRED.filter((key) => !process.env[key]);
if (missing.length) {
  console.error(`❌ Variáveis faltando no .env: ${missing.join(', ')}`);
  process.exit(1);
}

module.exports = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,
  guildId: process.env.GUILD_ID,
  confessionsChannelId: process.env.CONFESSIONS_CHANNEL_ID,
  reviewChannelId: process.env.REVIEW_CHANNEL_ID,
  gestaoRoleId: process.env.GESTAO_ROLE_ID,

  cooldownMs: Number(process.env.COOLDOWN_SECONDS ?? 60) * 1000,
  notifyAuthor: (process.env.NOTIFY_AUTHOR ?? 'true') === 'true',
  maxLength: 1800,

  colors: {
    brand: 0x9b59b6,
    pending: 0xf1c40f,
    approved: 0x2ecc71,
    rejected: 0xe74c3c,
  },
};
