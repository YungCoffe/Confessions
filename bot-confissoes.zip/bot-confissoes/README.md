# 🤫 Bot de Confissões

Confissões anônimas com aprovação da gestão.

**Fluxo**
1. A gestão roda `/painel-confissoes` num canal → o bot posta o painel com o botão **✍️ Enviar confissão**.
2. O membro escreve (nomes, @ e # liberados) → a confissão cai no **canal de revisão** (privado).
3. **Gestão+** clica em **✅ Aprovar** ou **❌ Recusar** (com motivo opcional).
4. Aprovada → é publicada de forma anônima no canal público, com um botão **🔎 Ver autor** que só funciona para Gestão+.
5. Cada consulta de autor deixa um registro no canal de revisão.

> "Gestão+" = cargo Gestão **ou qualquer cargo acima dele** na hierarquia (+ Administradores e dono).

## Estrutura

```
src/
├─ index.js              # inicia o bot
├─ config.js             # lê o .env e valida
├─ deploy-commands.js    # registra o slash command
├─ commands/painel.js    # /painel-confissoes
├─ handlers/
│  ├─ index.js           # roteia botões, modais e comandos
│  ├─ confession.js      # botão do painel + envio do formulário
│  ├─ review.js          # aprovar / recusar
│  └─ viewAuthor.js      # botão "Ver autor" (Gestão+)
└─ utils/                # embeds, permissões, cooldown, customIds
```

## Configuração

1. [Developer Portal](https://discord.com/developers/applications) → crie o app e o bot, copie o **token** e o **Application ID**. Não precisa ligar nenhum intent privilegiado.
2. Convide o bot com os escopos `bot` + `applications.commands` e as permissões: **Ver canais, Enviar mensagens, Incorporar links, Ler histórico**.
3. Crie o cargo **Gestão** e um canal de revisão visível **só** para Gestão+. O bot precisa de acesso a esse canal e ao canal público.
4. Copie `.env.example` para `.env` e preencha (Modo Desenvolvedor → botão direito → Copiar ID).
5. Rode:

```bash
npm install
npm run deploy   # registra o comando (só na primeira vez ou quando mudar comandos)
npm start
```


## Sem banco de dados

O autor fica gravado no rodapé do embed do **canal de revisão**, então tudo sobrevive a reinícios e funciona em hosts com disco temporário (Render free, por exemplo). Consequência: **não apague as mensagens do canal de revisão**, senão o "Ver autor" daquela confissão deixa de funcionar.

## Hospedagem (Render)

- Como **Web Service**, defina as mesmas variáveis do `.env` no painel (a `PORT` o Render já fornece — o bot abre um health check simples).
- Build: `npm install` · Start: `npm start`.
